package com.payment.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payment.beans.Address;
import com.payment.beans.CTS_Manager;
import com.payment.beans.CTS_Person;
import com.payment.dao.DaoManager;

public class UTest {
	private DaoManager dManager;
	@Before
	public void setUp() throws Exception {
		dManager=new DaoManager();
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		//fail("Not yet implemented");
	 // CTS_Person per=new CTS_Person();
	  CTS_Manager mang=new CTS_Manager();
	  //per.setName("Prashanth");
	  mang.setN_Projects(5);
	  mang.setLeaveApproval(true);
	  
	  Address ad=new Address();
	  ad.setCity("chennai");
	  ad.setCountry("india");
	  
	  
		
	}

}
