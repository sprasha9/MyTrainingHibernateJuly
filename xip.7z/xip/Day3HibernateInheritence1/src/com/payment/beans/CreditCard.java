package com.payment.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="creditcard")
//@DiscriminatorValue(value="CreditCardObject")
public class CreditCard extends Payment {
@Column(name="creditCardNo")
	private long creditCardNo;
@Column(name="ccName")
	private String ccName;
@Column(name="ccCVV")
	private int ccCVV;
@Temporal(TemporalType.DATE)
@Column(name="ccExpDate")
	private Date ccExpDate;
@Column(name="ccEMI")
	private Boolean ccEMI;
	
	
	public long getCreditCardNo() {
		return creditCardNo;
	}
	
	public void setCreditCardNo(long creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	
	public String getCcName() {
		return ccName;
	}
	
	public void setCcName(String ccName) {
		this.ccName = ccName;
	}
	
	public int getCcCVV() {
		return ccCVV;
	}
	
	public void setCcCVV(int ccCVV) {
		this.ccCVV = ccCVV;
	}
	
	public Date getCcExpDate() {
		return ccExpDate;
	}
	
	public void setCcExpDate(Date ccExpDate) {
		this.ccExpDate = ccExpDate;
	}
	
	public Boolean getCcEMI() {
		return ccEMI;
	}
	
	public void setCcEMI(Boolean ccEMI) {
		this.ccEMI = ccEMI;
	}
	
}
