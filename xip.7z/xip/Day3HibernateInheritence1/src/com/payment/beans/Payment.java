package com.payment.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Table(name="payment")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
//@DiscriminatorColumn(name="object_name",discriminatorType=DiscriminatorType.STRING)
//@DiscriminatorValue(value="PaymentObj")
public class Payment {
@Id
//@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="payment_id")
	private int pay_id;
@Column(name="cus_id")
	private int customer_id;
@Column(name="amount")
	private int amount;
@Column(name="dot")
	private Date DOT;
	
	
	
	public int getPay_id() {
		return pay_id;
	}
	public void setPay_id(int pay_id) {
		this.pay_id = pay_id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int cudtomer_id) {
		this.customer_id = cudtomer_id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Date getDOT() {
		return DOT;
	}
	public void setDOT(Date dOT) {
		DOT = dOT;
	}
	
}
