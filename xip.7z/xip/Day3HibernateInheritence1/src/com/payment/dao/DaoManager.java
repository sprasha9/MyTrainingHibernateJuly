package com.payment.dao;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.payment.beans.Payment;
import com.payment.resources.HibernateUtil;

public class DaoManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
		
	}
	
	public boolean AddPayment(Payment payment)
	{
		session=factory.openSession();
		session.beginTransaction();
		try {
			session.save(payment);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
			
		}
		return status;
		
	}
}
